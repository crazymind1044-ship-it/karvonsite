export default function SectionLabel({ children, variant = 'cyan' }) {
  const colors = { cyan: 'text-primary', muted: 'text-muted-foreground' };
  return (
    <div className={`inline-flex items-center gap-3 font-mono text-xs tracking-[0.14em] uppercase ${colors[variant]}`}>
      <span className="w-5 h-px bg-current" />
      {children}
    </div>
  );
}