import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const links = [
  { href: '#solutie', label: 'Soluție' },
  { href: '#proces', label: 'Tehnologie' },
  { href: '#roadmap', label: 'Roadmap' },
  { href: '#calculator', label: 'Calculator' },
  { href: '#echipa', label: 'Echipă' },
  { href: '#contact', label: 'Contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', fn);
    return () => window.removeEventListener('scroll', fn);
  }, []);
  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 px-6 lg:px-10 h-[72px] flex items-center justify-between transition-all duration-500 ${scrolled ? 'bg-[#0A0F12]/95 backdrop-blur-xl border-b border-primary/10' : ''}`}>
        <a href="#" className="font-heading text-2xl font-[900] text-foreground tracking-tight">
          <span className="text-primary">K</span>ARVON
        </a>
        <ul className="hidden lg:flex items-center gap-8">
          {links.map(l => <li key={l.href}><a href={l.href} className="font-mono text-[11px] tracking-[0.1em] uppercase text-muted-foreground hover:text-primary transition-colors duration-200">{l.label}</a></li>)}
        </ul>
        <a href="#contact" className="hidden lg:inline-flex bg-primary text-primary-foreground px-5 py-2.5 rounded-full text-xs font-bold tracking-widest uppercase hover:shadow-[0_0_30px_rgba(0,245,255,0.3)] transition-all duration-300">Solicită Ofertă</a>
        <button onClick={() => setMenuOpen(true)} className="lg:hidden text-foreground"><Menu className="w-6 h-6" /></button>
      </nav>
      <div className={`fixed inset-0 z-[100] transition-transform duration-500 ease-out ${menuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="absolute inset-0 bg-[#0A0F12]/98 backdrop-blur-2xl" />
        <div className="relative h-full flex flex-col p-8">
          <button onClick={() => setMenuOpen(false)} className="self-end text-foreground mb-12"><X className="w-7 h-7" /></button>
          <div className="flex flex-col gap-6">
            {links.map(l => <a key={l.href} href={l.href} onClick={() => setMenuOpen(false)} className="font-heading text-3xl font-bold text-foreground hover:text-primary transition-colors">{l.label}</a>)}
          </div>
          <a href="#contact" onClick={() => setMenuOpen(false)} className="mt-auto bg-primary text-primary-foreground py-4 rounded-full text-center text-sm font-bold tracking-widest uppercase">Solicită Ofertă</a>
        </div>
      </div>
    </>
  );
}