import { motion } from 'framer-motion';

export default function ScrollReveal({ children, className = '', delay = 0, direction = 'up' }) {
  const directions = { up: { y: 40, x: 0 }, left: { y: 0, x: -40 }, right: { y: 0, x: 40 }, none: { y: 0, x: 0 } };
  const { y, x } = directions[direction] || directions.up;
  return (
    <motion.div className={className} initial={{ opacity: 0, y, x }} whileInView={{ opacity: 1, y: 0, x: 0 }}
      viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.8, delay: delay / 1000, ease: [0.21, 0.47, 0.32, 0.98] }}>
      {children}
    </motion.div>
  );
}

export function StaggerContainer({ children, className = '', staggerDelay = 0.1 }) {
  return (
    <motion.div className={className} initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-60px' }}
      variants={{ hidden: {}, visible: { transition: { staggerChildren: staggerDelay } } }}>
      {children}
    </motion.div>
  );
}

export function StaggerItem({ children, className = '', direction = 'up' }) {
  const directions = { up: { y: 30, x: 0 }, left: { y: 0, x: -30 }, right: { y: 0, x: 30 } };
  const { y, x } = directions[direction] || directions.up;
  return (
    <motion.div className={className}
      variants={{ hidden: { opacity: 0, y, x, scale: 0.97 }, visible: { opacity: 1, y: 0, x: 0, scale: 1, transition: { duration: 0.7, ease: [0.21, 0.47, 0.32, 0.98] } } }}>
      {children}
    </motion.div>
  );
}