import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Marquee from '../components/Marquee';
import ProblemSolution from '../components/ProblemSolution';
import Process from '../components/Process';
import NarrativeInterstitial from '../components/NarrativeInterstitial';
import Roadmap from '../components/Roadmap';
import Calculator from '../components/Calculator';
import ProductConfigurator from '../components/ProductConfigurator';
import FAQ from '../components/FAQ';
import Team from '../components/Team';
import Contact from '../components/Contact';
import Footer from '../components/Footer';
import ChatWidget from '../components/ChatWidget';

const HERO_IMG = 'https://media.base44.com/images/public/6a108486344c3c055dde3d61/d5d083dc1_generated_ac0ffdd8.png';
const PROCESS_IMG = 'https://media.base44.com/images/public/6a108486344c3c055dde3d61/a756666c3_generated_16ed364f.png';

export default function Home() {
  return (
    <div className="bg-background text-foreground min-h-screen overflow-x-hidden">
      <Navbar />
      <Hero heroImage={HERO_IMG} />
      <Marquee />
      <ProblemSolution />
      <Process processImage={PROCESS_IMG} />
      <NarrativeInterstitial />
      <Roadmap />
      <ProductConfigurator />
      <Calculator />
      <FAQ />
      <Team />
      <Contact />
      <Footer />
      <ChatWidget />
    </div>
  );
}